package com.example.shopgrid;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private ProductAdapter adapter;
    private final List<Product> allProducts = new ArrayList<>();
    private final List<Product> visibleProducts = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView recyclerView = findViewById(R.id.productsRecyclerView);
        EditText searchInput = findViewById(R.id.searchInput);
        TextView filterText = findViewById(R.id.filterText);
        ImageView backButton = findViewById(R.id.backButton);
        ImageView gridButton = findViewById(R.id.gridButton);

        addSampleProducts();
        visibleProducts.addAll(allProducts);

        // Two-column grid matches the reference design.
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));
        adapter = new ProductAdapter(this, visibleProducts);
        recyclerView.setAdapter(adapter);

        searchInput.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                filterProducts(s.toString());
            }
            @Override public void afterTextChanged(Editable s) { }
        });

        filterText.setOnClickListener(v ->
                Toast.makeText(this, "Filter options can be added here", Toast.LENGTH_SHORT).show());
        backButton.setOnClickListener(v -> finish());
        gridButton.setOnClickListener(v ->
                Toast.makeText(this, "Showing products in grid view", Toast.LENGTH_SHORT).show());
    }

    private void addSampleProducts() {
        allProducts.add(new Product("Bitzwolf B-CC1 Camera", "US$48.89", R.drawable.product_camera_tripod));
        allProducts.add(new Product("Mini Instant Printer", "US$55.89", R.drawable.product_printer));
        allProducts.add(new Product("Smart Indoor Camera", "US$78.89", R.drawable.product_indoor_camera));
        allProducts.add(new Product("Compact Action Camera", "US$88.55", R.drawable.product_action_camera));
        allProducts.add(new Product("HD Webcam", "US$23.67", R.drawable.product_webcam));
        allProducts.add(new Product("Bitzwolf B-CC1 Camera", "US$44.89", R.drawable.product_camera_tripod));
    }

    private void filterProducts(String query) {
        visibleProducts.clear();
        String normalized = query.trim().toLowerCase(Locale.ROOT);
        for (Product product : allProducts) {
            if (product.getName().toLowerCase(Locale.ROOT).contains(normalized)) {
                visibleProducts.add(product);
            }
        }
        adapter.notifyDataSetChanged();
    }
}
